<?php?>
    <header>
        <ul>
                <li>
                    <a href="login.html">Вход</a>
                </li>
                <li>
                    <a href="default.php">Главная</a>
                </li>
                <li>
                    <a href="newnote.php">Новая заметка</a>
                </li>
                <li>
                    <a href="email.php">Отправить сообщение</a>
                </li>
                <li>
                    <a href="photo.php">Добавить фото</a>
                </li>
                <li>
                    <a href="inform.php">Статистика</a>
                </li>
                <li>
                    <a href="admin.php">Администратору</a>
                </li>
                <li>
                    <a href = "radio.php">Переключатели</a>
                </li>
                <li>
                    <a href = "search.php">Поиск</a>
                </li>
                <li>
                    <a href="logout.php">Выход</a>
                </li>
                
        </ul>
    </header>
<?php ?>