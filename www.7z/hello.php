<html>
    <head>
    <title>Test Page</title>
    </head>
    <body>
    <?php
    echo "Hello, World!"
    ?>
    </body>
</html>